package com.cg.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;



import com.cg.capstore.dto.CapStoreRevenue;
import com.cg.capstore.dto.Order;
import com.cg.capstore.service.ICapStoreService;



@Controller
public class OrderController {
	@Autowired
	ICapStoreService capstoreService;
	
	@RequestMapping(value="all")
	public ModelAndView getAll(Model model,Order order)
	{
//		String id=order.getOrder_Id();
		float price=capstoreService.getRefundPrice("1");
		System.out.println(price);
		//model.addAttribute("price",price);
		
		return new ModelAndView("refundamount","price",price);
	}
	
	@RequestMapping(value="revenue")
	public ModelAndView updateRevenue(Model model,Order order)
	{
		
		float price=capstoreService.getRefundPrice("1");
		float revenue=capstoreService.getRevenueDetails("1");
	

		float updatedRevenue=revenue-price;
	

		CapStoreRevenue cpsr=new CapStoreRevenue();
		cpsr.setOrder_Id("1");
		cpsr.setRevenue(updatedRevenue);
		capstoreService.setNewRevenue(cpsr);
		
		return new ModelAndView("success","newprice",price);
		
	}

}
