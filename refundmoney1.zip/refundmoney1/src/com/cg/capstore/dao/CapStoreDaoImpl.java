package com.cg.capstore.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;




import com.cg.capstore.dto.CapStoreRevenue;
import com.cg.capstore.dto.Order;

@Repository
@Transactional
public class CapStoreDaoImpl implements ICapStoreDao {

	
	@PersistenceContext
	EntityManager manager;
	
	
	public EntityManager getManager() {
		return manager;
	}


	public void setManager(EntityManager manager) {
		this.manager = manager;
	}
	@Override
	public float getRefundPrice(String Order_Id) {
		 Order ord=manager.find(Order.class, Order_Id);
		 System.out.println(ord);
			return ord.getTotal_price();
	
	}


	@Override
	public float getRevenueDetails(String Order_Id) {
		CapStoreRevenue cap=manager.find(CapStoreRevenue.class, Order_Id);
		 
			return cap.getRevenue();
		
	}


	@Override
	public void setNewRevenue(CapStoreRevenue rev) {
		manager.merge(rev);
		manager.flush();
		
	}


	

	

}


