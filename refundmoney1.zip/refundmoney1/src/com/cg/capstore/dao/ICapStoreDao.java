package com.cg.capstore.dao;

import com.cg.capstore.dto.CapStoreRevenue;


public interface ICapStoreDao {
	public  float getRefundPrice(String Order_Id);
	public  float getRevenueDetails(String Order_Id);
	public void setNewRevenue(CapStoreRevenue rev);
}
