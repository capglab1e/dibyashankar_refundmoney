package com.cg.capstore.dto;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="order_details")
public class Order {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ORDER_ID")
	private String Order_Id;
	
	private String Order_Status;
	
	
	private float total_price;

	private Date order_date;
	
	private String payment_Id;
	 
	private String coupon_Id;
	 private String Prod_Id;

	public Date getOrder_date() {
		return order_date;
	}

	public void setOrder_date(Date order_date) {
		this.order_date = order_date;
	}

	public String getPayment_Id() {
		return payment_Id;
	}

	public void setPayment_Id(String payment_Id) {
		this.payment_Id = payment_Id;
	}

	public String getCoupon_Id() {
		return coupon_Id;
	}

	public void setCoupon_Id(String coupon_Id) {
		this.coupon_Id = coupon_Id;
	}

	public String getProd_Id() {
		return Prod_Id;
	}

	public void setProd_Id(String prod_Id) {
		Prod_Id = prod_Id;
	}

	public String getOrder_Id() {
		return Order_Id;
	}

	public void setOrder_Id(String order_Id) {
		Order_Id = order_Id;
	}

	
	

	@Override
	public String toString() {
		return "Order [Order_Id=" + Order_Id + ", Order_Status=" + Order_Status
				+ ", total_price=" + total_price + "]";
	}

	public String getOrder_Status() {
		return Order_Status;
	}

	public void setOrder_Status(String order_Status) {
		Order_Status = order_Status;
	}

	
	public float getTotal_price() {
		return total_price;
	}

	public void setTotal_price(float total_price) {
		this.total_price = total_price;
	}
	
	
	
	
}
