package com.cg.capstore.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.ICapStoreDao;
import com.cg.capstore.dto.CapStoreRevenue;


@Service("service")
@Transactional
public class CapStoreServiceImpl implements ICapStoreService{
	@Autowired
	ICapStoreDao capstoreDao;
	@Override
	public float getRefundPrice(String Order_Id) {
		// TODO Auto-generated method stub
		return capstoreDao.getRefundPrice(Order_Id);
	}
	@Override
	public float getRevenueDetails(String Order_Id) {
		// TODO Auto-generated method stub
		return capstoreDao.getRevenueDetails(Order_Id);
	}
	@Override
	public void setNewRevenue(CapStoreRevenue rev){
		// TODO Auto-generated method stub
		capstoreDao.setNewRevenue(rev);
	}
	

}
